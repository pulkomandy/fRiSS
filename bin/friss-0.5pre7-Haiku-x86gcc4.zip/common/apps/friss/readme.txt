This source code is distributed because I am too lazy get make release once a year.

You can find the official binaries for download at:

	http://www.bebits.com/app/3898

	http://www.herzig-net.de/prog/?page=friss


Writing mails might encourage me to continue developing.

Otherwise use this code under MIT licence (basically do what you want, just state it's based on my code originally. That's it.)